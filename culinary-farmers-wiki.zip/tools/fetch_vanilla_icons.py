#!/usr/bin/env python3
"""Baixa as imagens dos itens do Minecraft usados nas receitas (maçã, açúcar, ovo…).

Fonte: repositório PrismarineJS/minecraft-assets (texturas do jogo, uso para fãs/sem fins lucrativos).
Uso:   python3 tools/fetch_vanilla_icons.py
Depois rode de novo o tools/build_wiki.py para a wiki passar a usar as imagens.
"""
import json
import os
import subprocess

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE = "https://raw.githubusercontent.com/PrismarineJS/minecraft-assets/master/data/%s/%s/%s.png"
VERSIONS = ["1.21.8", "1.21.4", "1.21.1", "1.20.2"]
FOLDERS = ["items", "blocks"]


def fetch(short, out):
    for v in VERSIONS:
        for folder in FOLDERS:
            r = subprocess.run(["curl", "-sSf", "-m", "20", "-o", out, BASE % (v, folder, short)],
                               capture_output=True)
            if r.returncode == 0 and os.path.getsize(out) > 0:
                return v + "/" + folder
            if os.path.exists(out):
                os.remove(out)
    return None


def main():
    with open(os.path.join(ROOT, "data", "wiki.json"), encoding="utf-8") as fh:
        ids = sorted(json.load(fh)["vanilla"])
    ids += ["minecraft:rabbit_stew", "minecraft:beetroot_soup", "minecraft:mushroom_stew"]  # pratos do jogo base usados nas panelas
    dest = os.path.join(ROOT, "img", "v")
    os.makedirs(dest, exist_ok=True)
    ok, missing = [], []
    for i in ids:
        short = i.split(":")[-1]
        src = fetch(short, os.path.join(dest, short + ".png"))
        (ok if src else missing).append(short)
        print(("ok  " if src else "FALTOU ") + short, src or "")
    print("baixados:", len(ok), "| sem imagem:", missing)


if __name__ == "__main__":
    main()
