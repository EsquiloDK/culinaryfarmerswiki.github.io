#!/usr/bin/env python3
"""Gera os dados da wiki (data/wiki.json) e as imagens (img/) a partir do addon.

Uso:  python3 tools/build_wiki.py caminho/Culinary_Farmers.mcaddon
Rode de dentro da pasta da wiki. Requer Python 3 e a biblioteca Pillow (pip install pillow).
"""
import glob
import json
import os
import re
import shutil
import sys
import tempfile
import zipfile
from datetime import date

from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LANGS = {"pt": "pt_BR", "en": "en_US"}


# ---------------------------------------------------------------- extração
def safe_extract(zf, dest):
    base = os.path.abspath(dest)
    for n in zf.namelist():
        target = os.path.abspath(os.path.join(dest, n))
        if not target.startswith(base + os.sep):
            continue
        if n.endswith("/"):
            os.makedirs(target, exist_ok=True)
            continue
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, "wb") as fh:
            fh.write(zf.read(n))


def open_addon(src):
    if os.path.isdir(src):
        return src
    tmp = tempfile.mkdtemp(prefix="cf_addon_")
    with zipfile.ZipFile(src) as z:
        safe_extract(z, tmp)
    for p in glob.glob(os.path.join(tmp, "**", "*.mcpack"), recursive=True):
        with zipfile.ZipFile(p) as z:
            safe_extract(z, p + "_x")
    return tmp


def find_pack(root, name):
    for p in glob.glob(os.path.join(root, "**", name), recursive=True):
        if os.path.isdir(p):
            return p
    raise SystemExit("Pasta %s não encontrada no addon" % name)


# ---------------------------------------------------------------- utilidades
def read_lang(path):
    out = {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.rstrip("\n")
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            out[k.strip()] = v.split("\t#")[0].replace("\\n", "\n").strip()
    return out


def jload(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def clean(text):
    text = re.sub("§.", "", text or "")
    return text.split("\n")[0].strip()


def titleize(ident):
    return ident.split(":")[-1].replace("_", " ").title()


# Nomes em português dos itens do jogo base que aparecem em receitas.
VANILLA_PT = {
    "apple": "Maçã", "sugar": "Açúcar", "egg": "Ovo", "wheat": "Trigo",
    "beef": "Carne crua", "cooked_beef": "Bife", "chicken": "Frango cru",
    "cooked_chicken": "Frango cozido", "carrot": "Cenoura", "potato": "Batata",
    "baked_potato": "Batata assada", "bread": "Pão", "milk_bucket": "Balde de leite",
    "cocoa_beans": "Cacau", "bowl": "Tigela", "glass_bottle": "Garrafa de vidro",
    "iron_ingot": "Barra de ferro", "porkchop": "Costeleta de porco crua",
    "cooked_porkchop": "Costeleta de porco cozida", "cod": "Bacalhau cru",
    "cooked_cod": "Bacalhau cozido", "salmon": "Salmão cru", "cooked_salmon": "Salmão cozido",
    "beetroot": "Beterraba", "brown_mushroom": "Cogumelo marrom",
    "red_mushroom": "Cogumelo vermelho", "rabbit": "Coelho cru",
    "cooked_rabbit": "Coelho cozido", "sweet_berries": "Frutas vermelhas",
    "glow_berries": "Frutas luminosas", "honey_bottle": "Garrafa de mel",
    "melon_slice": "Fatia de melancia", "melon": "Melancia", "pumpkin": "Abóbora",
    "wheat_seeds": "Sementes de trigo", "book": "Livro", "bone": "Osso",
    "flint_and_steel": "Isqueiro", "flint": "Pederneira", "emerald": "Esmeralda",
    "water_bucket": "Balde de água", "bucket": "Balde", "water": "Água",
    "milk": "Leite", "planks": "Tábuas", "oak_planks": "Tábuas de carvalho",
    "stick": "Graveto", "iron_nugget": "Pepita de ferro", "glass": "Vidro",
    "glass_pane": "Painel de vidro", "paper": "Papel", "leather": "Couro",
    "cookie": "Biscoito", "pumpkin_seeds": "Sementes de abóbora",
    "melon_seeds": "Sementes de melancia", "beetroot_seeds": "Sementes de beterraba",
    "bone_meal": "Farinha de osso", "clay_ball": "Bola de argila", "gold_ingot": "Barra de ouro",
    "gold_nugget": "Pepita de ouro", "golden_carrot": "Cenoura dourada",
    "mutton": "Carneiro cru", "cooked_mutton": "Carneiro cozido", "honey_block": "Bloco de mel",
    "dirt": "Terra", "sand": "Areia", "cocoa": "Cacau", "red_dye": "Corante vermelho",
    "yellow_dye": "Corante amarelo", "ink_sac": "Bolsa de tinta", "oak_log": "Tronco de carvalho",
    "log": "Tronco", "coal": "Carvão", "charcoal": "Carvão vegetal", "lava_bucket": "Balde de lava",
    "blaze_powder": "Pó de chamas", "glowstone_dust": "Pó de glowstone", "potion": "Poção",
    "water_bottle": "Garrafa de água", "dried_kelp": "Alga seca", "kelp": "Alga",
    "sugar_cane": "Cana-de-açúcar", "spider_eye": "Olho de aranha", "rotten_flesh": "Carne podre",
    "bamboo": "Bambu", "blue_egg": "Ovo azul", "brown_egg": "Ovo marrom", "cake": "Bolo",
    "tropical_fish": "Peixe tropical", "pufferfish": "Baiacu", "iron_ingot ": "Barra de ferro",
}
BIOME_NAMES = {
    "oak_forest": ("Floresta de carvalhos", "Oak forest"),
    "flower_forest": ("Floresta de flores", "Flower forest"),
    "forest": ("Floresta", "Forest"), "birch": ("Bétula", "Birch"),
    "jungle": ("Selva", "Jungle"), "bamboo_jungle": ("Selva de bambu", "Bamboo jungle"),
    "taiga": ("Taiga", "Taiga"), "beach": ("Praia", "Beach"), "plains": ("Planície", "Plains"),
    "savanna": ("Savana", "Savanna"), "meadow": ("Prado", "Meadow"),
    "extreme_hills": ("Montanhas", "Mountains"), "mesa": ("Mesa (badlands)", "Mesa (badlands)"),
    "ocean": ("Oceano", "Ocean"), "cold": ("frio", "cold"), "mushroom_island": ("Ilha de cogumelos", "Mushroom island"),
    "swamp": ("Pântano", "Swamp"), "desert": ("Deserto", "Desert"), "stone": ("rochoso", "stony"),
}
VANILLA_DISH = {"rabbit_stew_pot": "rabbit_stew", "beetroot_soup_pot": "beetroot_soup", "mushroom_soup_pot": "mushroom_stew"}
SPECIAL_POT = {
    "cream": ("Creme de leite", "Cream"),
    "condensed_milk": ("Leite condensado", "Condensed milk"),
}


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    addon = open_addon(sys.argv[1])
    bp, rp = find_pack(addon, "CF_BP"), find_pack(addon, "CF_RP")

    lang = {code: read_lang(os.path.join(rp, "texts", f + ".lang")) for code, f in LANGS.items()}
    item_tex = jload(os.path.join(rp, "textures", "item_texture.json"))["texture_data"]
    terr_tex = jload(os.path.join(rp, "textures", "terrain_texture.json"))["texture_data"]

    def tex_path(table, name):
        t = table.get(name, {}).get("textures")
        if isinstance(t, list):
            t = t[0]
        if isinstance(t, dict):
            t = t.get("path")
        return t

    img_dir = os.path.join(ROOT, "img", "i")
    shutil.rmtree(img_dir, ignore_errors=True)  # img/v (itens do jogo base) é mantida
    os.makedirs(img_dir, exist_ok=True)

    def save_icon(ident, rel):
        if not rel:
            return None
        src = os.path.join(rp, rel + ".png")
        if not os.path.exists(src):
            return None
        out = ident.split(":")[-1] + ".png"
        shutil.copyfile(src, os.path.join(img_dir, out))
        return "img/i/" + out

    def name_of(ident):
        short = ident.split(":")[-1]
        res = {}
        for code in LANGS:
            res[code] = clean(lang[code].get("item." + ident) or lang[code].get("tile.%s.name" % ident)) or titleize(ident)
        return res

    groups = {}
    for key, val in lang["pt"].items():
        if key.startswith("cf:itemGroup.name."):
            g = key.split(".")[-1]
            groups[g] = {c: clean(lang[c].get(key, g)) for c in LANGS}
    GROUP_NAMES = {
        "sapling": ("Mudas", "Saplings"), "crop": ("Frutas, legumes e ingredientes", "Fruits, vegetables and ingredients"),
        "seed": ("Sementes", "Seeds"), "miscFood": ("Alimentos diversos", "Misc food"),
        "roasts": ("Pratos assados", "Roasts"), "cookedFood": ("Alimentos cozidos", "Cooked food"),
        "flower": ("Plantas silvestres", "Wild plants"), "items": ("Ingredientes", "Ingredients"),
        "crates": ("Caixotes", "Crates"), "pots": ("Panelas", "Pots"),
    }
    for g, (pt_n, en_n) in GROUP_NAMES.items():
        if g not in groups or groups[g]["pt"] == g:
            groups[g] = {"pt": pt_n, "en": en_n}
    category_fallback = {
        "nature": {"pt": "Plantas e ingredientes", "en": "Plants and ingredients"},
        "construction": {"pt": "Blocos", "en": "Blocks"},
        "equipment": {"pt": "Pratos e comidas", "en": "Dishes and food"},
        "items": {"pt": "Ingredientes", "en": "Ingredients"},
    }

    # ---------------------------------------------------------------- itens
    SKIP = {"cf:falling_coconut", "cf:pot_ingredient", "cf:recipe_book_placed", "cf:wiki_book_placed"}
    items = {}
    for f in sorted(glob.glob(os.path.join(bp, "items", "*.json"))):
        d = jload(f)["minecraft:item"]
        ident = d["description"]["identifier"]
        if ident in SKIP:
            continue
        comps = d.get("components", {})
        menu = d["description"].get("menu_category", {})
        icon_name = comps.get("minecraft:icon")
        if isinstance(icon_name, dict):
            icon_name = icon_name.get("textures", {}).get("default")
        entry = {
            "name": name_of(ident),
            "group": (menu.get("group") or "").split(".")[-1] or menu.get("category", "items"),
            "icon": save_icon(ident, tex_path(item_tex, icon_name) if icon_name else None),
            "kind": "item",
        }
        food = comps.get("minecraft:food")
        if food:
            entry["food"] = {"nutrition": food.get("nutrition"), "saturation": food.get("saturation_modifier")}
        if "minecraft:max_stack_size" in comps:
            entry["stack"] = comps["minecraft:max_stack_size"]
        items[ident] = entry

    # blocos que aparecem no inventário
    wood = Image.open(os.path.join(rp, "textures", "blocks", "crate_wood.png")).convert("RGBA")
    for f in sorted(glob.glob(os.path.join(bp, "blocks", "*.json"))):
        d = jload(f)["minecraft:block"]
        ident = d["description"]["identifier"]
        menu = d["description"].get("menu_category", {})
        grp = (menu.get("group") or "").split(".")[-1]
        if not grp or menu.get("category") == "none" or ident in items:
            continue
        if grp not in ("crates", "pots", "flower") and ident != "cf:salt_block":
            continue
        mi = d.get("components", {}).get("minecraft:material_instances", {})
        pick = lambda k: (mi.get(k) or {}).get("texture") if isinstance(mi.get(k), dict) else mi.get(k)
        icon = None
        short = ident.split(":")[-1]
        if grp == "crates":
            fruit = tex_path(terr_tex, pick("fruit"))
            if fruit:
                # caixote: fruta no miolo, moldura e ripa do meio em madeira
                fr = Image.open(os.path.join(rp, fruit + ".png")).convert("RGBA")
                w2 = wood.resize(fr.size, Image.NEAREST)
                n = fr.width
                m = max(2, n // 8)
                base = fr.copy()
                for yy in range(n):
                    for xx in range(n):
                        edge = xx < m or yy < m or xx >= n - m or yy >= n - m
                        slat = n // 2 - 1 <= yy <= n // 2
                        if edge or slat:
                            base.putpixel((xx, yy), w2.getpixel((xx, yy)))
                base.save(os.path.join(img_dir, short + ".png"))
                icon = "img/i/" + short + ".png"
        else:
            icon = save_icon(ident, tex_path(terr_tex, pick("*") or pick("body")))
        items[ident] = {"name": name_of(ident), "group": grp or "other", "icon": icon, "kind": "block"}

    # panela de um prato: usa a imagem do prato (ex.: cf:beef_stew_pot -> cf:beef_stew)
    for ident, it in items.items():
        short = ident.split(":")[-1]
        if it["group"] == "pots" and short.endswith("_pot"):
            dish = items.get("cf:" + short[:-4])
            if dish and dish.get("icon"):
                it["icon"] = dish["icon"]
            elif short in VANILLA_DISH and os.path.exists(os.path.join(ROOT, "img", "v", VANILLA_DISH[short] + ".png")):
                it["icon"] = "img/v/" + VANILLA_DISH[short] + ".png"  # prato que já existe no jogo base

    for ident, it in items.items():
        if it["group"] not in groups:
            groups[it["group"]] = category_fallback.get(it["group"], {"pt": it["group"].title(), "en": it["group"].title()})

    # ---------------------------------------------------------------- receitas
    vanilla = set()

    def norm_ing(ing):
        if isinstance(ing, str):
            return ing
        if "item" in ing:
            return ing["item"]
        if "tag" in ing:
            return "tag:" + ing["tag"]
        return "?"

    def track(i):
        if i and not i.startswith("cf:") and not i.startswith("tag:") and i != "?":
            vanilla.add(i)

    recipes = []
    for f in sorted(glob.glob(os.path.join(bp, "recipes", "*.json"))):
        d = jload(f)
        key = [k for k in d if k.startswith("minecraft:recipe")][0]
        r = d[key]
        station = (r.get("tags") or ["crafting_table"])[0]
        rid = r["description"]["identifier"]
        if key == "minecraft:recipe_shapeless":
            ing = [norm_ing(i) for i in r["ingredients"]]
            res = r["result"]
            rec = {"id": rid, "type": "shapeless", "station": station, "ingredients": ing,
                   "result": res["item"], "count": res.get("count", 1)}
        elif key == "minecraft:recipe_shaped":
            keymap = {k: norm_ing(v) for k, v in r["key"].items()}
            grid = [[keymap.get(ch, "") if ch != " " else "" for ch in row.ljust(3)] for row in r["pattern"]]
            res = r["result"]
            if isinstance(res, list):
                res = res[0]
            ing = sorted(set(i for row in grid for i in row if i))
            rec = {"id": rid, "type": "shaped", "station": station, "grid": grid, "ingredients": ing,
                   "result": res["item"], "count": res.get("count", 1)}
        else:
            inp = r["input"]
            inp = inp["item"] if isinstance(inp, dict) else inp
            out = r["output"]
            out = out["item"] if isinstance(out, dict) else out
            rec = {"id": rid, "type": "cook", "station": station, "ingredients": [inp], "result": out, "count": 1}
        for i in rec["ingredients"] + [rec["result"]]:
            track(i)
        recipes.append(rec)

    # panela (definidas no código do addon)
    stew = open(os.path.join(bp, "scripts", "stew.js"), encoding="utf-8").read()
    idx_block = re.search(r"INGREDIENT_INDEX\s*=\s*\{(.*?)\};", stew, re.S).group(1)
    index_item = {int(n): i for i, n in re.findall(r'"([a-z_:]+)":\s*(\d+)', idx_block)}
    consts = dict(re.findall(r"const (MILK|CREAM|CONDENSED)\s*=\s*(\d+)", stew)) if False else {"MILK": 1, "CREAM": 2, "CONDENSED": 3}
    for m in re.finditer(r"\{\s*name:\s*\"(\w+)\",\s*liquid:\s*(\w+),\s*ingredients:\s*\[([^\]]*)\](.*?)\}", stew):
        name, liquid, ings, rest = m.groups()
        liquid = int(liquid) if liquid.isdigit() else consts.get(liquid, 0)
        ids = [index_item[int(x)] for x in re.findall(r"\d+", ings)]
        res = re.search(r'result:\s*"([\w:]+)"', rest)
        rec = {"id": "pot:" + name, "type": "pot", "station": "pot", "liquid": liquid, "ingredients": ids,
               "result": res.group(1) if res else None, "count": 1}
        if name in SPECIAL_POT or not res:
            rec["special"] = name
        for i in ids:
            track(i)
        recipes.append(rec)
    recipes.append({"id": "pot:cream", "type": "pot", "station": "pot", "liquid": 1, "ingredients": [],
                    "tool": "minecraft:flint_and_steel", "result": None, "special": "cream", "count": 1})
    track("minecraft:flint_and_steel")

    # nomes dos itens do jogo base
    van = {}
    for i in sorted(vanilla):
        short = i.split(":")[-1]
        van[i] = {"en": titleize(i), "pt": VANILLA_PT.get(short, titleize(i))}
    missing_pt = [i for i in van if i.split(":")[-1] not in VANILLA_PT]

    # ---------------------------------------------------------------- plantas e mundo
    def collect(filt):
        inc, exc, mode = [], [], "any"

        def walk(node, m):
            nonlocal mode
            if isinstance(node, list):
                for n in node:
                    walk(n, m)
            elif isinstance(node, dict):
                if "any_of" in node:
                    walk(node["any_of"], "any")
                elif "all_of" in node:
                    mode = "all"
                    walk(node["all_of"], "all")
                elif node.get("test") == "has_biome_tag":
                    (exc if node.get("operator") == "!=" else inc).append(node["value"])
        walk(filt, "any")
        return mode, inc, exc

    features = {}
    for f in glob.glob(os.path.join(bp, "feature_rules", "*.json")):
        r = jload(f)["minecraft:feature_rules"]
        mode, inc, exc = collect(r["conditions"].get("minecraft:biome_filter", []))
        features[r["description"]["places_feature"].split(":")[-1].replace("_feature", "")] = {
            "mode": mode, "in": inc, "out": exc}

    biomes = {}
    for tag in {t for v in features.values() for t in v["in"] + v["out"]}:
        pt, en = BIOME_NAMES.get(tag, (tag.replace("_", " "), tag.replace("_", " ")))
        biomes[tag] = {"pt": pt, "en": en}

    plant_defs = [
        # chave, tipo, semente/muda, produto, ícone, feição no mundo, nome pt, nome en
        ("corn", "crop", "cf:corn_seeds", "cf:corn", "cf:wild_corn", "wild_corn", "Milho", "Corn"),
        ("tomato", "crop", "cf:tomato_seeds", "cf:tomato", "cf:wild_tomato", "wild_tomato", "Tomate", "Tomato"),
        ("lettuce", "crop", "cf:lettuce_seeds", "cf:lettuce", "cf:wild_lettuce", "wild_lettuce", "Alface", "Lettuce"),
        ("pepper", "crop", "cf:pepper_seeds", "cf:pepper", "cf:wild_pepper", "wild_pepper", "Pimenta", "Pepper"),
        ("pineapple", "crop", "cf:pineapple_seeds", "cf:pineapple", "cf:wild_pineapple", "wild_pineapple", "Abacaxi", "Pineapple"),
        ("onion", "crop", "cf:onion", "cf:onion", "cf:wild_onion", "wild_onion", "Cebola", "Onion"),
        ("blueberry", "bush", "cf:blueberry", "cf:blueberry", "cf:blueberry", "blueberry_bush", "Mirtilo", "Blueberry"),
        ("apple", "tree", "cf:apple_sapling_item", "minecraft:apple", "cf:apple_sapling_item", "apple_tree", "Macieira", "Apple tree"),
        ("pear", "tree", "cf:pear_sapling_item", "cf:pear", "cf:pear_sapling_item", "pear_tree", "Pereira", "Pear tree"),
        ("orange", "tree", "cf:orange_sapling_item", "cf:orange", "cf:orange_sapling_item", "orange_tree", "Laranjeira", "Orange tree"),
        ("lemon", "tree", "cf:lemon_sapling_item", "cf:lemon", "cf:lemon_sapling_item", "lemon_tree", "Limoeiro", "Lemon tree"),
        ("mango", "tree", "cf:mango_sapling_item", "cf:mango", "cf:mango_sapling_item", "mango_tree", "Mangueira", "Mango tree"),
        ("banana", "tree", "cf:banana_sapling_item", "cf:banana", "cf:banana_sapling_item", "banana_tree", "Bananeira", "Banana tree"),
        ("coconut", "tree", "cf:coconut_palm_sapling", "cf:coconut", "cf:coconut_palm_sapling", "coconut_palm_cluster", "Coqueiro", "Coconut palm"),
    ]
    plants = []
    for key, kind, seed, product, icon_id, feat, pt, en in plant_defs:
        seed_ok = seed in items
        prod_ok = product in items or product.startswith("minecraft:")
        ic = (items.get(icon_id) or items.get(product) or items.get(seed) or {}).get("icon")
        if product.startswith("minecraft:"):
            track(product)
            van.setdefault(product, {"en": titleize(product), "pt": VANILLA_PT.get(product.split(":")[-1], titleize(product))})
        plants.append({"id": key, "kind": kind, "name": {"pt": pt, "en": en}, "seed": seed if seed_ok else None,
                       "product": product if prod_ok else None, "icon": ic, "world": features.get(feat)})
    salt = {"id": "salt", "kind": "other", "name": {"pt": "Sal", "en": "Salt"}, "seed": None,
            "product": "cf:salt" if "cf:salt" in items else None,
            "icon": (items.get("cf:salt") or items.get("cf:salt_block") or {}).get("icon"),
            "world": features.get("salt_patch")}
    plants.append(salt)

    # trocas com aldeões que envolvem itens do addon
    trades = []
    for f in glob.glob(os.path.join(bp, "trading", "**", "*.json"), recursive=True):
        prof = os.path.basename(f).replace(".json", "")
        for ti, tier in enumerate(jload(f).get("tiers", [])):
            for g in tier.get("groups", []):
                for t in g.get("trades", []):
                    w = [(x["item"], x.get("quantity", 1)) for x in t.get("wants", [])]
                    gv = [(x["item"], x.get("quantity", 1)) for x in t.get("gives", [])]
                    if any(i.startswith("cf:") for i, _ in w + gv):
                        for i, _ in w + gv:
                            track(i)
                        trades.append({"profession": prof, "tier": ti + 1, "wants": w, "gives": gv})
    for i in vanilla:
        van.setdefault(i, {"en": titleize(i), "pt": VANILLA_PT.get(i.split(":")[-1], titleize(i))})
    for i, v in van.items():
        local = "img/v/" + i.split(":")[-1] + ".png"
        if os.path.exists(os.path.join(ROOT, local)):
            v["icon"] = local

    # ---------------------------------------------------------------- guia (texto do livro do jogo)
    chapters = [
        ("intro", ["intro"]), ("crops", ["crops", "wild"]),
        ("trees", ["trees", "blueberry", "banana", "coconut"]),
        ("pot", ["pot_setup", "pot_liquids", "pot_dishes1", "pot_dishes2"]),
        ("roasts", ["roasts"]), ("sweets", ["cakes", "pies"]), ("drinks", ["drinks"]),
        ("snacks", ["snacks"]), ("extras", ["crates", "extras"]),
        ("thanks", ["thanks"]), ("credits", ["credits"]),
    ]
    guide = []
    for cid, pages in chapters:
        ch = {"id": cid, "title": {c: lang[c].get("cf.wiki.c_" + cid, cid) for c in LANGS}, "pages": []}
        for p in pages:
            ch["pages"].append({
                "id": p,
                "title": {c: lang[c].get("cf.wiki.%s.t" % p, p) for c in LANGS},
                "body": {c: lang[c].get("cf.wiki.%s.b" % p, "") for c in LANGS},
            })
        guide.append(ch)

    manifest = jload(os.path.join(bp, "manifest.json"))
    version = ".".join(str(x) for x in manifest["header"]["version"])
    shutil.copyfile(os.path.join(bp, "pack_icon.png"), os.path.join(ROOT, "img", "logo.png"))

    special_names = {k: {"pt": v[0], "en": v[1]} for k, v in SPECIAL_POT.items()}
    data = {
        "meta": {"version": version, "generated": date.today().isoformat(),
                 "name": {"pt": "Culinary Farmer's", "en": "Culinary Farmer's"}},
        "groups": groups, "items": items, "vanilla": van, "recipes": recipes, "plants": plants,
        "biomes": biomes, "trades": trades, "guide": guide, "specialNames": special_names,
    }
    os.makedirs(os.path.join(ROOT, "data"), exist_ok=True)
    with open(os.path.join(ROOT, "data", "wiki.json"), "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, separators=(",", ":"))

    print("itens:", len(items), "| receitas:", len(recipes), "| plantas:", len(plants),
          "| trocas:", len(trades), "| versão do addon:", version)
    print("sem ícone:", [i for i, v in items.items() if not v["icon"]])
    print("itens do jogo base sem tradução manual (pt):", missing_pt)
    print("plantas sem semente/produto:", [(p["id"], p["seed"], p["product"]) for p in plants if not p["seed"] or not p["product"]])
    print("grupos:", {k: v["pt"] for k, v in groups.items()})


if __name__ == "__main__":
    main()
