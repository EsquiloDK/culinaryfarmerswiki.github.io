# Culinary Farmer's — Wiki

Wiki do addon **Culinary Farmer's** (Minecraft Bedrock), em português e inglês.
Feita por EsquiloDK. Wiki não oficial; Minecraft é marca da Mojang/Microsoft.

## Como publicar

1. Crie um repositório novo no GitHub (ex.: `culinary-farmers-wiki`) como **público**.
2. Envie todo o conteúdo desta pasta (Add file → Upload files).
3. Em **Settings → Pages**, escolha *Deploy from a branch*, branch `main`, pasta `/ (root)` e salve.
4. O site fica em `https://SEU-USUARIO.github.io/culinary-farmers-wiki/`.

## Como atualizar quando o addon mudar

Os dados vêm direto do arquivo `.mcaddon`. No computador, com Python e Pillow (`pip install pillow`):

```
python3 tools/build_wiki.py caminho/para/Culinary_Farmers.mcaddon
```

Isso refaz `data/wiki.json` e as imagens do addon (`img/i`). Depois é só enviar os arquivos novos para o GitHub.

## Onde mudar as coisas

- Links do rodapé: início do `app.js` (lista `LINKS`).
- Textos da interface: `app.js` (objeto `T`, em `pt` e `en`).
- Cores e visual: `style.css` (variáveis no começo).
- Texto dos capítulos do guia: vem das traduções do addon (`pt_BR.lang` e `en_US.lang`).

## Imagens dos itens do Minecraft

As imagens de maçã, açúcar, ovo etc. (`img/v`) são texturas do jogo, da Mojang, usadas aqui só como fã, sem fins lucrativos. Para baixar de novo: `python3 tools/fetch_vanilla_icons.py` e depois `python3 tools/build_wiki.py ...`.
